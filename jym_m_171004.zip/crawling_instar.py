import requests
from bs4 import BeautifulSoup

def getImg_instar():
    url = 'https://www.instagram.com/jym_joyfulyouthmission/'
    source_code = requests.get(url, allow_redirects=False)
    plain_text = source_code.text
    soup = BeautifulSoup(plain_text, 'html.parser')

    a = soup.findAll('a')

    print(a)
    
    div = soup.findAll('div', {'class': '_mck9w _gvoze _f2mse'})
    
    return

if __name__ == "__main__":
    getImg_instar()
