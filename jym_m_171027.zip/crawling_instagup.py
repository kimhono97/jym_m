import requests
from bs4 import BeautifulSoup

def get_img(soup):
    lst = []
    div = soup.findAll('div', {'class': 'post-masonry-media loading'})

    for x in div:
        x = str(x)
        a = x.find('src="https')
        x = x[a+5:]
        a = x.find('"')
        img = x[:a]
        a = x.find('-time">')
        x = x[a+7:]
        a = x.find('</span>')
        day = x[:a]
        lst.append([img, day])

    return lst

def get_stat(soup):
    lst = []
    div = soup.findAll('div', {'class': 'post-masonry-stats'})
    
    for x in div:
        x = str(x)
        a = x.find('count">')
        x = x[a+7:]
        a = x.find('</span>')
        likes = x[:a]
        a = x.find('count">')
        x = x[a+7:]
        a = x.find('</span>')
        comments = x[:a]
        lst.append([likes, comments])

    return lst

def get_instagup():
    lst = []
    url = 'http://www.instagup.com/profile/jym_joyfulyouthmission'
    source_code = requests.get(url, allow_redirects=False)
    plain_text = source_code.text
    soup = BeautifulSoup(plain_text, 'html.parser')

    imgs = get_img(soup)

    stats = get_stat(soup)

    for i in range(len(imgs)):
        dic = {}
        dic['img'] = imgs[i][0]
        dic['day'] = imgs[i][1]
        dic['likes'] = stats[i][0]
        dic['comments'] = stats[i][1]
        dic['url'] = url
        lst.append(dic)
    
    return lst

if __name__ == "__main__":
    get_instagup()
